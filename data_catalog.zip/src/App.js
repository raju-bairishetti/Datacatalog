
import React, { useEffect, useState } from "react";
import {
  Box, Grid, Paper, Typography, TextField, Table, TableBody, TableCell,
  TableRow, TableHead, Chip, Button, Select, MenuItem, CircularProgress
} from "@mui/material";
import { Search } from "@mui/icons-material";
import axios from "axios";
import yaml from "js-yaml";

const OWNER_LIST = { "ally_branch": { owner: "Jane Doe", consumers: ["ACME Bank", "BetaCorp"], sla: "99.9%, 24h", contact: "jane.doe@email.com" } };

const COUNTRIES = ["US", "IN", "SG"];

function fetchReport(table, date, country) {
  return axios.get(`/gx_${table}_${date}_${country}.json`).then(r => r.data).catch(() => null);
}

function getLatestBizDate() {
  return "20250901";
}

function App() {
  const [search, setSearch] = useState("");
  const [schema, setSchema] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [selected, setSelected] = useState(null);
  const [schemaSearch, setSchemaSearch] = useState({ name: "", type: "", tag: "", description: "" });
  const [selectedCountry, setSelectedCountry] = useState("");
  const [reports, setReports] = useState({});
  const [loadingReports, setLoadingReports] = useState(false);

  // Load schema.yml
  useEffect(() => {
    axios.get("/ally_schema.yml")
      .then(res => {
        const doc = yaml.load(res.data);
        if (doc && doc.models) {
          setSchema(doc.models);
          setFiltered(doc.models);
        }
      });
  }, []);

  useEffect(() => {
    if (search === "") setFiltered(schema);
    else setFiltered(schema.filter(
      m => m.name.toLowerCase().includes(search.toLowerCase())
      || (m.description && m.description.toLowerCase().includes(search.toLowerCase()))
    ));
  }, [search, schema]);

  // Load reports for selected product
  useEffect(() => {
    async function loadReports() {
      setLoadingReports(true);
      const date = getLatestBizDate();
      const product = selected?.name;
      let out = {};
      if (product) {
        await Promise.all(COUNTRIES.map(async country => {
          const rep = await fetchReport(product, date, country);
          if (rep) out[country] = rep;
        }));
      }
      setReports(out);
      setLoadingReports(false);
    }
    loadReports();
    setSelectedCountry("");
  }, [selected]);

  let ownerInfo = selected && OWNER_LIST[selected.name];

  // Schema search filtering
  const filteredColumns = selected
    ? selected.columns.filter(col =>
        (col.name || "").toLowerCase().includes(schemaSearch.name.toLowerCase()) &&
        (col.data_type || "").toLowerCase().includes(schemaSearch.type.toLowerCase()) &&
        ((col.tags ? col.tags.join(" ") : "")).toLowerCase().includes(schemaSearch.tag.toLowerCase()) &&
        (col.description || "").toLowerCase().includes(schemaSearch.description.toLowerCase())
      )
    : [];

  // Report summary
  const repKeys = Object.keys(reports);
  const numReports = repKeys.length;
  const [successCount, pendingCount] = [
    repKeys.filter(c => reports[c]?.statistics?.successful_expectations === reports[c]?.statistics?.evaluated_expectations).length,
    repKeys.filter(c => reports[c]?.statistics?.successful_expectations !== reports[c]?.statistics?.evaluated_expectations).length
  ];

  // By default show US first for dropdown
  const defaultCountry = repKeys[0] || "";

  // Chosen report details
  const chosenRep = reports[selectedCountry || defaultCountry];

  return (
    <Box p={4} sx={{ background: "#f6f8fb", minHeight: "100vh" }}>
      <Typography variant="h4" sx={{ fontWeight: 700, color: "#153A5F" }}>
        Data Product Catalog (Rich UI)
      </Typography>
      <TextField
        variant="outlined"
        placeholder="Search data product"
        sx={{ my: 3, width: 400 }}
        InputProps={{ startAdornment: <Search sx={{ mr:1 }}/>, "data-testid": "search-field"}}
        value={search}
        onChange={e => setSearch(e.target.value)}
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <Paper elevation={3} sx={{ p: 2 }}>
            {filtered && filtered.length > 0
              ? filtered.map((p, i) => (
                  <Button
                    key={p.name}
                    fullWidth
                    onClick={() => setSelected(p)}
                    variant={selected?.name === p.name ? "contained" : "outlined"}
                    sx={{ mb: 1, justifyContent: "left", fontWeight: 600, fontSize: 16 }}
                  >
                    {p.name}
                  </Button>
                ))
              : <Typography>No products found.</Typography>
            }
          </Paper>
        </Grid>
        <Grid item xs={12} md={9}>
          {selected &&
            <Paper elevation={4} sx={{ p: 3 }}>
              <Typography variant="h5" sx={{ mb: 1, color: "#0A2235" }}>{selected.name}</Typography>
              <Typography variant="body1" sx={{ color: "#48607B", mb: 2 }}>{selected.description}</Typography>
              <Grid container spacing={2}>
                {/* Schema */}
                <Grid item xs={12} md={7}>
                  <Box display="flex" gap={1} mb={2}>
                    <TextField size="small" label="Column" sx={{ flex:1 }} value={schemaSearch.name} onChange={e => setSchemaSearch(s => ({...s, name:e.target.value}))} />
                    <TextField size="small" label="Type" sx={{ flex:1 }} value={schemaSearch.type} onChange={e => setSchemaSearch(s => ({...s, type:e.target.value}))} />
                    <TextField size="small" label="Tag" sx={{ flex:1 }} value={schemaSearch.tag} onChange={e => setSchemaSearch(s => ({...s, tag:e.target.value}))} />
                    <TextField size="small" label="Description" sx={{ flex:1 }} value={schemaSearch.description} onChange={e => setSchemaSearch(s => ({...s, description:e.target.value}))} />
                  </Box>
                  <Paper>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell><b>Name</b></TableCell>
                          <TableCell><b>Type</b></TableCell>
                          <TableCell><b>Tag</b></TableCell>
                          <TableCell><b>Description</b></TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {filteredColumns.map(col => (
                          <TableRow key={col.name}>
                            <TableCell>{col.name}</TableCell>
                            <TableCell>{col.data_type}</TableCell>
                            <TableCell>
                              {(col.tags||[]).map(t =>
                                <Chip key={t} color={t==="pii"?"error":"primary"} size="small" label={t.toUpperCase()} sx={{mr:0.5}} />
                              )}
                            </TableCell>
                            <TableCell>{col.description}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </Paper>
                  {ownerInfo && (
                    <Typography sx={{ mt: 2, fontStyle:"italic", color: "#aaa" }}>
                      Contact: {ownerInfo.contact}
                    </Typography>
                  )}
                </Grid>
                {/* Owner & Reports */}
                <Grid item xs={12} md={5}>
                  <Paper elevation={1} sx={{ p: 2, mb: 2, background: "#E7F2FC" }}>
                    <Typography variant="subtitle1" fontWeight={600} mb={0.5}><b>Owner</b>: {ownerInfo?.owner}</Typography>
                    <Typography variant="subtitle2"><b>Consumers</b>: {ownerInfo?.consumers?.join(", ")}</Typography>
                    <Typography variant="body2"><b>SLA</b>: {ownerInfo?.sla}</Typography>
                  </Paper>
                  {/* Report summary & dropdown */}
                  <Paper elevation={1} sx={{ p: 2 }}>
                    <Typography variant="subtitle1">Great Expectations (DQ)</Typography>
                    {loadingReports ? (
                      <CircularProgress size={20}/>) : (
                      <>
                        <Typography variant="body2" mb={1}>
                          Reports: {numReports} | Success: {successCount} | Pending: {pendingCount}
                        </Typography>
                        <Select
                          fullWidth
                          displayEmpty
                          value={selectedCountry}
                          onChange={e => setSelectedCountry(e.target.value)}
                        >
                          <MenuItem value="">Select Country</MenuItem>
                          {repKeys.map(c => (
                            <MenuItem key={c} value={c}>{c}</MenuItem>
                          ))}
                        </Select>
                      </>
                    )}
                    <Box mt={2}>
                    {
                      chosenRep && (
                        <Box>
                          <Typography fontWeight={600}>Statistics</Typography>
                          <Typography variant="body2">Suite: {chosenRep.meta.expectation_suite_name}</Typography>
                          <Typography variant="body2">
                            Success: {chosenRep.statistics.successful_expectations} / {chosenRep.statistics.evaluated_expectations} 
                            &nbsp;({chosenRep.statistics.success_percent}%)
                          </Typography>
                          <Table size="small" sx={{ mt:1 }}>
                            <TableHead>
                              <TableRow>
                                <TableCell>Expectation</TableCell>
                                <TableCell>Result</TableCell>
                                <TableCell>Column</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {chosenRep.results.map((r,i) =>
                                <TableRow key={i} sx={{bgcolor: r.success ? "#C6F6D5" : "#FFF3CD"}}>
                                  <TableCell>{r.expectation_type}</TableCell>
                                  <TableCell>{r.success ? "✅" : "❌"}</TableCell>
                                  <TableCell>{r.column || "-"}</TableCell>
                                </TableRow>
                              )}
                            </TableBody>
                          </Table>
                          <Button size="small" sx={{ mt:1 }} target="_blank" href={`https://datahub.com/product/${selected.name}`}>View in DataHub</Button>
                        </Box>
                      )
                    }
                    </Box>
                  </Paper>
                </Grid>
              </Grid>
            </Paper>
          }
        </Grid>
      </Grid>
    </Box>
  );
}

export default App;
