
from flask import Flask, render_template, request, abort, url_for
import yaml, json, os
from collections import defaultdict

app = Flask(__name__)

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
LATEST_DATE = "20250901"

OWNER_MAP = {
    "ally_branch": {
        "owner": "Jane Doe",
        "consumers": ["ACME Bank", "BetaCorp"],
        "sla": "99.9%, 24h",
        "contact": "jane.doe@email.com",
    }
}

def load_schema():
    with open(os.path.join(DATA_DIR, "schema.yml"), "r") as f:
        doc = yaml.safe_load(f)
    models = doc.get("models", [])
    # Normalize records
    for m in models:
        m["columns"] = m.get("columns", [])
        for c in m["columns"]:
            c["tags"] = c.get("tags", [])
            c["data_type"] = c.get("data_type", "string")
            c["description"] = c.get("description", "")
    return models

def list_reports(table_name, date=LATEST_DATE):
    # expect files: gx_<table>_<date>_<COUNTRY>.json
    reports = {}
    for f in os.listdir(DATA_DIR):
        if f.startswith(f"gx_{table_name}_{date}_") and f.endswith(".json"):
            country = f.split("_")[-1].replace(".json", "")
            with open(os.path.join(DATA_DIR, f), "r") as jf:
                try:
                    reports[country] = json.load(jf)
                except Exception:
                    reports[country] = None
    return reports

def summarize_reports(reports):
    total = len(reports)
    success = 0
    pending = 0
    for _, rep in reports.items():
        if not rep:
            pending += 1
            continue
        stats = rep.get("statistics", {})
        if stats.get("successful_expectations") == stats.get("evaluated_expectations"):
            success += 1
        else:
            pending += 1
    return {"total": total, "success": success, "pending": pending}

@app.route("/")
def index():
    schema = load_schema()
    q = request.args.get("q", "").strip().lower()
    if q:
        filtered = [m for m in schema if q in m["name"].lower() or q in (m.get("description","").lower())]
    else:
        filtered = schema
    return render_template("index.html", products=filtered, query=q)

@app.route("/product/<name>")
def product(name):
    schema = load_schema()
    product = next((m for m in schema if m["name"] == name), None)
    if not product:
        abort(404)
    # column filters
    f_name = request.args.get("col", "").lower()
    f_type = request.args.get("type", "").lower()
    f_tag = request.args.get("tag", "").lower()
    f_desc = request.args.get("desc", "").lower()

    cols = []
    for c in product["columns"]:
        if f_name and f_name not in c["name"].lower():
            continue
        if f_type and f_type not in c.get("data_type","" ).lower():
            continue
        tags_join = " ".join([t.lower() for t in c.get("tags", [])])
        if f_tag and f_tag not in tags_join:
            continue
        if f_desc and f_desc not in c.get("description","" ).lower():
            continue
        cols.append(c)

    owner = OWNER_MAP.get(product["name"], {})
    reports = list_reports(product["name"], LATEST_DATE)
    summary = summarize_reports(reports)
    sel_country = request.args.get("country") or (list(reports.keys())[0] if reports else "")
    sel_report = reports.get(sel_country)

    return render_template(
        "product.html",
        product=product,
        columns=cols,
        owner=owner,
        reports=reports,
        summary=summary,
        selected_country=sel_country,
        selected_report=sel_report,
        latest_date=LATEST_DATE,
        filters={"col": f_name, "type": f_type, "tag": f_tag, "desc": f_desc},
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
